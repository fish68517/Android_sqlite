论文包说明
1. Android_Diary_Thesis.docx：可编辑论文源文件
2. Android_Diary_Thesis.pdf：论文PDF版
3. drawio/：系统架构图、功能结构图、流程图、数据库ER图的draw.io原始文件
4. diagram_png/：插入论文中的流程图与结构图PNG版
5. screenshot_placeholders/：论文中用于占位的页面截图PNG，可按需替换
